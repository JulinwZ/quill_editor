/**
 * @license Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'filetools', 'en', {
	loadError: 'Error occurred during file read.',
	networkError: 'Network error occurred during file upload.',
	httpError404: 'HTTP error occurred during file upload (404: File not found).',
	httpError403: 'HTTP error occurred during file upload (403: Forbidden).',
	httpError: 'HTTP error occurred during file upload (error status: %1).',
	noUrlError: 'Upload URL is not defined.',
	responseError: 'Incorrect server response.'
} );
