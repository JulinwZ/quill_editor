/**
 * @license Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'filetools', 'ku', {
	loadError: 'هەڵەیەک ڕوویدا لە ماوەی خوێندنەوەی پەڕگەکە.',
	networkError: 'هەڵەیەکی ڕایەڵە ڕوویدا لە ماوەی بارکردنی پەڕگەکە.',
	httpError404: 'هەڵەیەک ڕوویدا لە ماوەی بارکردنی پەڕگەکە (404: پەڕگەکە نەدۆزراوە).',
	httpError403: 'هەڵەیەک ڕوویدا لە ماوەی بارکردنی پەڕگەکە  (403: قەدەغەکراو).',
	httpError: 'هەڵەیەک ڕوویدا لە ماوەی بارکردنی پەڕگەکە (دۆخی هەڵە: %1).',
	noUrlError: 'بەستەری پەڕگەکە پێناسە نەکراوە.',
	responseError: 'وەڵامێکی نادروستی سێرڤەر.'
} );
