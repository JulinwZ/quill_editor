/**
 * @license Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'filetools', 'hr', {
	loadError: 'Greška prilikom čitanja datoteke.',
	networkError: 'Mrežna greška prilikom slanja datoteke.',
	httpError404: 'HTTP greška tijekom slanja datoteke (404: datoteka nije pronađena).',
	httpError403: 'HTTP greška tijekom slanja datoteke  (403: Zabranjeno).',
	httpError: 'HTTP greška tijekom slanja datoteke (greška status: %1).',
	noUrlError: 'URL za slanje nije podešen.',
	responseError: 'Neispravni odgovor servera.'
} );
