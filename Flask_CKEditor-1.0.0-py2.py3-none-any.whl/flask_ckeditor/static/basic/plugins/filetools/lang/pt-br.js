/**
 * @license Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'filetools', 'pt-br', {
	loadError: 'Um erro ocorreu durante a leitura do arquivo.',
	networkError: 'Um erro de rede ocorreu durante o envio do arquivo.',
	httpError404: 'Um erro HTTP ocorreu durante o envio do arquivo (404: Arquivo não encontrado).',
	httpError403: 'Um erro HTTP ocorreu durante o envio do arquivo (403: Proibido).',
	httpError: 'Um erro HTTP ocorreu durante o envio do arquivo (status do erro: %1)',
	noUrlError: 'A URL de upload não está definida.',
	responseError: 'Resposta incorreta do servidor.'
} );
