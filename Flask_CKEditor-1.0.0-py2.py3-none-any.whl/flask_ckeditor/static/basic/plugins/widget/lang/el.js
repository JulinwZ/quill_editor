/**
 * @license Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'widget', 'el', {
	'move': 'Κάνετε κλικ και σύρετε το ποντίκι για να μετακινήστε',
	'label': '%1 widget' // MISSING
} );
